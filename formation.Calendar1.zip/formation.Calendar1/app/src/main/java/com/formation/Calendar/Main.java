package com.formation.Calendar;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.formation.Calendar.CalendarView.OnDispatchDateSelectListener;

public class Main extends Activity implements OnDispatchDateSelectListener{
	private TextView 			mTextDate;
	private SimpleDateFormat 	mFormat;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mTextDate=(TextView)findViewById(R.id.display_date);
        
        mFormat = new SimpleDateFormat("EEEE d MMMM yyyy");
        
        ((CalendarView) findViewById(R.id.calendar)).setOnDispatchDateSelectListener(this);
    }

	@Override
	public void onDispatchDateSelect(Date date) {
		mTextDate.setText(mFormat.format(date));		
	}
}